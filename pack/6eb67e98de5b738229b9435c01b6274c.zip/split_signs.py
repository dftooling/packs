from PIL import Image, ImageDraw
import json
import random

TEX_BASE = "assets/city/textures/block/sign/large/"
MDL_BASE = "assets/city/models/block/sign/large/"


SPLITS = {
    "j1_immediate_eastbound": [
        (0, 0, 2, 2, 1, 1),
        (2, 0, 2, 2, 0, 1),
        (0, 2, 2, 1, 1, 1),
        (2, 2, 2, 1, 0, 1)
    ],
    "j1_immediate_westbound": [
        (0, 0, 2, 2, 1, 1),
        (2, 0, 2, 2, 0, 1),
        (0, 2, 2, 1, 1, 1),
        (2, 2, 2, 1, 0, 1)
    ]
}

def c(r: int, g: int, b: int) -> int:
    return (r << 16) + (g << 8) + b

REPLACEMENTS = {
    c(0, 123, 193): [
        (0, 123, 193),
        (15, 129, 191),
        (22, 132, 191)
    ],
    c(255, 255, 255): [
        (255, 255, 255),
        (239, 239, 239),
        (226, 226, 226)
    ],
    c(204, 59, 59): [
        (204, 59, 59),
        (204, 65, 65),
        (204, 77, 77)
    ],
    c(22, 22, 22): [
        (25, 22, 22),
        (38, 38, 38),
        (58, 58, 58)
    ]
}

def process_image(im: Image.Image) -> Image.Image:
    for x in range(im.width):
        for y in range(im.height):
            col = im.getpixel((x, y))
            r = REPLACEMENTS.get(c(col[0], col[1], col[2]), None)
            if r == None:
                continue
            new = r[random.randint(0, len(r)-1)]
            im.putpixel((x, y), new + (255,))
    return im

for name, splits in SPLITS.items():
    print(f"Processing {name}")
    im = Image.open(f"{TEX_BASE}{name}.png").convert("RGBA")
    im = process_image(im)
    for i, split in enumerate(splits):
        out = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        sect = im.crop((split[0]*16, split[1]*16, (split[0]+split[2])*16, (split[1]+split[3])*16))
        out.paste(sect, (split[4]*16, split[5]*16))
        draw = ImageDraw.ImageDraw(out, "RGBA")
        draw.rectangle((48, 0, 64, 64), (255, 0, 0, 255))
        draw.rectangle((0, 48, 64, 64), (255, 0, 0, 255))
        out.save(f"{TEX_BASE}{name}_{i}.png")

        back = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        back.paste(Image.new("RGBA", (48, 48), (160, 160, 160, 255)), (0, 0), out.crop((0, 0, 48, 48)).transpose(Image.FLIP_LEFT_RIGHT))
        draw = ImageDraw.ImageDraw(back, "RGBA")
        draw.rectangle((48, 0, 64, 64), (255, 0, 0, 255))
        draw.rectangle((0, 48, 64, 64), (255, 0, 0, 255))
        back.save(f"{TEX_BASE}{name}_{i}_back.png")

        f = open(f"{MDL_BASE}{name}_{i}.json", "w+")
        json.dump({
            "parent": "city:block/sign/base_large",
            "textures": {
                "front": f"city:block/sign/large/{name}_{i}",
                "back": f"city:block/sign/large/{name}_{i}_back"
            }
        }, f)
        f.close()