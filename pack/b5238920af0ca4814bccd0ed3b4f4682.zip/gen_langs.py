import os
import json

BASE = "assets/minecraft/lang"

LANGS = ["af_za.json","ar_sa.json","ast_es.json","az_az.json","ba_ru.json","bar.json","be_by.json","be_latn.json","bg_bg.json","br_fr.json","brb.json","bs_ba.json","ca_es.json","cs_cz.json","cy_gb.json","da_dk.json","de_at.json","de_ch.json","de_de.json","el_gr.json","en_au.json","en_ca.json","en_gb.json","en_nz.json","en_pt.json","en_ud.json","en_us.json","enp.json","enws.json","eo_uy.json","es_ar.json","es_cl.json","es_ec.json","es_es.json","es_mx.json","es_uy.json","es_ve.json","esan.json","et_ee.json","eu_es.json","fa_ir.json","fi_fi.json","fil_ph.json","fo_fo.json","fr_ca.json","fr_fr.json","fra_de.json","fur_it.json","fy_nl.json","ga_ie.json","gd_gb.json","gl_es.json","haw_us.json","he_il.json","hi_in.json","hr_hr.json","hu_hu.json","hy_am.json","id_id.json","ig_ng.json","io_en.json","is_is.json","isv.json","it_it.json","ja_jp.json","jbo_en.json","ka_ge.json","kk_kz.json","kn_in.json","ko_kr.json","ksh.json","kw_gb.json","la_la.json","lb_lu.json","li_li.json","lmo.json","lo_la.json","lol_us.json","lt_lt.json","lv_lv.json","lzh.json","mk_mk.json","mn_mn.json","ms_my.json","mt_mt.json","nah.json","nds_de.json","nl_be.json","nl_nl.json","nn_no.json","no_no.json","oc_fr.json","ovd.json","pl_pl.json","pt_br.json","pt_pt.json","qya_aa.json","ro_ro.json","rpr.json","ru_ru.json","ry_ua.json","sah_sah.json","se_no.json","sk_sk.json","sl_si.json","so_so.json","sq_al.json","sr_cs.json","sr_sp.json","sv_se.json","sxu.json","szl.json","ta_in.json","th_th.json","tl_ph.json","tlh_aa.json","tok.json","tr_tr.json","tt_ru.json","tzo_mx.json","uk_ua.json","val_es.json","vec_it.json","vi_vn.json","vp_vl.json","yi_de.json","yo_ng.json","zh_cn.json","zh_hk.json","zh_tw.json","zlm_arab.json"]

OVERRIDES = {
    "block.minecraft.prismarine_wall": "Display Entity Collision & Break Detection Block §c[DO NOT BREAK THESE] §a[@bt]"
}

for lang in LANGS:
    file = os.path.join(BASE, lang)
    f = open(file, "w+")
    json.dump(OVERRIDES, f)
    f.close()