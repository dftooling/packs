import json


MODEL_DATA = {
    1: "city:item/car",
    2: "city:block/lighting_column_base",
    3: "city:block/lighting_column_midsection",
    4: "city:block/lighting_column_lantern",
    5: "city:block/lighting_column_small_lantern",
    6: "city:block/lighting_column_wall_mount",
    7: "city:block/sign/no_entry",
    8: "city:block/sign/give_way",
    9: "city:block/sign/enter_motorway",
    10: "city:block/sign/exit_motorway"
}


feather = {
    "parent": "item/generated",
    "textures": {
        "layer0": "item/feather"
    },
    "display": {
        "head": {
            "rotation": [ 0, 0, 45 ],
            "translation": [ -1, 13, 7],
            "scale":[ 1, 1, 1]
        }
    },
    "overrides": [
    ]
}

wall = {
    "parent": "minecraft:item/barrier",
    "overrides": [
    ]
}

for i, model in MODEL_DATA.items():
    override = {
        "predicate": {
            "custom_model_data": i
        },
        "model": model
    }
    feather["overrides"].append(override)
    wall["overrides"].append(override)

f = open("assets/minecraft/models/item/feather.json", "w+")
json.dump(feather, f)
f.close()

f = open("assets/minecraft/models/item/prismarine_wall.json", "w+")
json.dump(wall, f)
f.close()